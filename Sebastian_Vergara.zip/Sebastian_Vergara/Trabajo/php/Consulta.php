
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Datos Personales</title>
    <link rel="stylesheet" type="text/css" href="css/Alumno.css">
    </head>
  <script type="text/javascript">
        function Salida(){
        window.location.href=".../Alumno.php";
        }
        
    </script> 
    <style type="text/css">
    @media print {
            #botonimprimir, #salir, #btnreset ,#btnconsultar,#cedula,#cedulatxt,#imprimir{
                display: none;
            }
        }
    
    </style>
    <body>
    <center>
       <form ACTION="<?php $_SERVER['PHP_SELF']?>" method="POST">

           <div id ="titulo">Datos Personales</div>
        
           <label id="cedula">Cedula(Rut)</label>
           <input id="cedulatxt" name="cedulatxt" type="text" pattern="^(\d{2}\.\d{3}\.\d{3}-)([a-zA-Z]{1}$|\d{1}$)"placeholder="xx.xxx.xxx-x" required> 
           
           <input type="submit" id="btnconsultar" name="submit" value="Consulta">
           <input type="button" id="salir" value="Salir" onclick="window.location.href='../Alumno.php';">
           <input type="button" id="imprimir"value="Imprimir" onclick="window.print()">
            </form>
        </center>
<?php
    
            $nombredelservidor = "localhost";
            $nombredeusuario = "Sebastian";
            $clave = "xxx1234";
            $basededatos="registro";

            $conn = new mysqli ($nombredelservidor, $nombredeusuario, $clave, $basededatos);
             
             
if(isset($_POST['submit'])){
            if(!empty($_POST)){
		          if($_POST["cedulatxt"]!=""){ 
                     $Cedula = ($_POST["cedulatxt"]);
			         $sql1= "select * from alumnos where (Cedula_Al=\"$Cedula\") ";
			         $query = $conn->query($sql1);
                     if($r=$query->fetch_array()){
                    echo  "<center>";
                    echo "Rut: " . $r["Cedula_Al"];
                    echo "<br>";  
                    echo "Nombre: " . $r["Nombre_Al"];
                    echo "<br>"; 
                    echo "Apellido: " . $r["Apellidos_Al"];
                      echo "<br>"; 
                    echo "Fecha de Nacimiento: " . $r["FechaNacimiento_Al"];
                      echo "<br>"; 
                    echo "Edad: " . $r["Edad_Al"];
                      echo "<br>"; 
                    echo "Sexo: " . $r["Sexo_Al"];
                      echo "<br>"; 
                    echo "Direccion: " . $r["Direccion_Al"];
                      echo "<br>"; 
                    echo "Telefono: " . $r["Telefono_Al"];
                      echo "<br>"; 
                    echo "Provinicia: " . $r["Provincia_Al"];
                      echo "<br>"; 
                    echo "Ciudad: " . $r["Ciudad_Al"];
                      echo "<br>"; 
                    echo "Pais: " . $r["Pais_Al"];
                     echo  "</center>" ;
                         
                        }else{
                       echo  "<center>";
                      echo "no existe el rut";
                      echo  "</center>" ; 
                  }
                      
			}
		}
	}
    ?>    
    </body>
</html>