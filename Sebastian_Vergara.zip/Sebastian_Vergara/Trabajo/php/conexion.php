<?php

$nombredelservidor = "localhost";
$nombredeusuario = "Sebastian";
$clave = "xxx1234";
$basededatos="registro";
$conexion = mysqli_connect($nombredelservidor, $nombredeusuario, $clave, $basededatos);


?>