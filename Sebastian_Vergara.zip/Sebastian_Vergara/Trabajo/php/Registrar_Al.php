<?php
if(isset($_POST['btnsubmit'])){
include 'conexion.php';
    
$Cedula = $_POST["cedulatxt"];
$Nombre = Trim($_POST["nombretxt"]);
$Apellidos = $_POST["apellidostxt"];
$Fechana = $_POST["fechanatxt"];
$Edad = $_POST["edadtxt"];
$Sexo = $_POST["sexotxt"];
$Direccion = $_POST["direcciontxt"];
$telefono = $_POST["telefonotxt"];
$Provincia = $_POST["provinciatxt"];
$Ciudad = Trim($_POST["ciudadtxt"]);
$Pais = $_POST["paistxt"];
    
$insertar = "INSERT INTO alumnos (Cedula_Al,Nombre_Al,Apellidos_Al, FechaNacimiento_Al, Edad_Al, Sexo_Al, Direccion_Al , Telefono_Al, Provincia_Al, Ciudad_Al, Pais_Al ) VALUES('$Cedula','$Nombre','$Apellidos','$Fechana', $Edad ,'$Sexo','$Direccion',$telefono,'$Provincia','$Ciudad','$Pais')";    
    
$Verificar_rut = mysqli_query($conexion, "SELECT * FROM alumnos WHERE Cedula_Al = '$Cedula'");
if (mysqli_num_rows($Verificar_rut)>0){
    echo '<script>
        alert("El rut ya esta registrado");
        window.history.go(-1)
        </script>
    ';
    exit;
}

$Resultado= mysqli_query($conexion, $insertar);

    if(!$Resultado){
        echo '<script>
            alert(("Error al registrar");
            window.history.go(-1)
            </script>
            ';
    } else {
        echo '<script>
        alert("Usuario Registrado exitosamente");
        window.history.go(-1)
        </script>
        ';
    }

    mysqli_close($conexion);
    
}
?>