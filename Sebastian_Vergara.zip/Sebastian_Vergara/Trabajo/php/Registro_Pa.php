<?php

$nombredelservidor = "localhost";
$nombredeusuario = "Sebastian";
$clave = "xxx1234";
$basededatos="registro";
$conexion = mysqli_connect($nombredelservidor, $nombredeusuario, $clave, $basededatos);

   

$username=$_POST['usuariotxt'];
$password=$_POST['clavetxt'];
 
 
$sql = "SELECT Usuario_Ad, Contrasena_Ad FROM administradores WHERE Usuario_Ad = '" . $username . "' and Contrasena_Ad='".$password."';";
$query=mysqli_query($conexion,$sql);
$counter=mysqli_num_rows($query);

if ($counter==1){
		echo "<script>alert(\"Usted a ingresado correctamente\");
        window.location='../Alumno.php';
        </script>";
}else{
    echo '<script>
        alert("Usuario o Contraseña incorrecta");
        window.history.go(-1)
        </script>
    ';
    exit;
} 

?>