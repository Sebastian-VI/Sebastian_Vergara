<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Principal</title>
    <link href="css/Pagina.css" rel="stylesheet">
     <link href = "https://fonts.googleapis.com/css?family= Noto + Serif + JP | Noto + Serif + KR | Abrir + Sans | Roboto " rel = "stylesheet">
    </head>   
      <script languague="javascript">
        function mostrar() {
            div = document.getElementById('flotante');
            div.style.display = '';
        }

        function cerrar() {
            div = document.getElementById('flotante');
            div.style.display = 'none';
        }
        function validar(){
    
        var txtUsuario = document.getElementById('Usuario').value;
        var txtClave = document.getElementById('Clave').value;

        ExpRegUsuario =/^[a-zA-Z]{6,10}$/;
        ExpRegClave = /^[a-zA-Z{1-9}]{6,8}$/;

        if(ExpRegUsuario.test(txtUsuario) == true && ExpRegClave.test(txtClave) == true ){
            if(txtUsuario.length == false ){
             alert("El Usuario debe tener 6 a 10 caracteristicas solo letras");
             return false;
            }
            if(txtClave.length == false ){
             alert("La clave debe tener 6 a 8 caracteristicas alfanumerico");
            return false;  
            }
            }  
             }
</script>  
    <center>
  <body>
       <img id="logo" src="img/LOGO%201.png">
      <div id="contenido"> 
      <p>Liceo Los Andes<br>Por favor para ingresar al sitio web presione el enlace <a href="javascript:mostrar();">Ingresar</a></p>
      <div id="flotante" style="display:none;">
          
        <form id="formulario" action="php/Registro_Pa.php" Method="POST">
        <input id="Usuario" name="usuariotxt" type="text" placeholder="&#128107; Usuario" pattern="^[A-Za-z]{6,10}$" required>  
        <input id="Clave" name="clavetxt" type="password" placeholder="&#128274; Contraseña" pattern="^[A-Za-z{1-9}]{6,8}$" required>
        
        <input type="submit" id="Sesion1" name="Sesion"  value="Iniciar sesión" onclick="validar();">   
        
        <input type="reset" id="Limpiar" value="Limpiar Datos">
        </form>
     <div id="close"><a href="javascript:cerrar();">Cerrar</a></div>
          </div>
          </div>

      
  </body> 
      </center> 
</html>