<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Datos Personales</title>
   <link href="css/Alumno.css" rel="stylesheet" type="text/css" media="screen">
    </head>
  <script type="text/javascript">
        function Salida(){
        window.location.href="Pagina.php";
        }
        function Guardar(){
        document.getElementById("form1").reset;
        }    
        
    </script>        
    <body>
    <center>
       <form id="form1" action="php/Registrar_Al.php"  method="POST">

           <div id ="titulo">Datos Personales</div>
        
           <label id="cedula">Cedula(Rut)</label>
           <input id="cedulatxt" required name="cedulatxt" type="text" pattern="^(\d{2}\.\d{3}\.\d{3}-)([a-zA-Z]{1}$|\d{1}$)" placeholder="xx.xxx.xxx-x">         
           <label id="presionar" >* Presione el boton de "Consulta" para verificar el Rut</label>
            

           <label id="nombre">Nombres(Primario/Secundario)</label>
           <input id="nombretxt" required name="nombretxt" type=text pattern="^[A-Za-z]{0,15}(\s)[A-Za-z]{0,15}$"> 
           <label id="apellidos">Apellidos(Paterno/Materno)</label>
           <input id="apellidostxt" required name="apellidostxt" type="text" pattern="^[A-Za-z]{0,15}(\s)[A-Za-z]{0,15}$">
           
           <label id="fechana">Fecha de Nacimiento</label>
           <input id="fechanatxt" required name="fechanatxt" type=text pattern="^([0-2][0-9]|3[0-1])(\/|-|.)(0[1-9]|1[0-2])\2(\d{4})$" placeholder="DD/MM/YYYY">
           
           <label id="edad">Edad</label>
           <input id="edadtxt" required name="edadtxt" type=text pattern="^[0-9]{1,2}$">
           
           <label id="sexo">Sexo</label>
           <select id="sexotxt" required name="sexotxt">
               <option ></option>
               <option Value="femenino">Femenino</option>
               <option Value ="masculino">Masculino</option>
           </select>
           
           <label id="direccion">Direccion</label>
           <input id="direcciontxt" required name="direcciontxt" type ="text" pattern="(^[A-Za-z]{0,30}).([A-Za-z]{0,30}.[A-Za-z]{0,30}.[A-Za-z]{0,30})$">
           
           <label id="telefono">Telefono</label>
           <input id="telefonotxt" required name="telefonotxt" type="text" pattern="^[0-9]{9,10}$">
           
           <label id="provincia">Provincia</label>
           <input id="provinciatxt" required name="provinciatxt" type="text" pattern="(^[A-Za-z]{0,30}).([A-Za-z]{0,30})$">
           
            <label id="ciudad">Ciudad</label>
           <input id="ciudadtxt" required name="ciudadtxt" type="text" pattern="(^[A-Za-z]{0,30}).([A-Za-z]{0,30})$">
           
           <label id="pais">Pais</label>
           <input id="paistxt" required name="paistxt" type ="text" pattern="(^[A-Za-z]{0,30}).([A-Za-z]{0,30})$">
           
           <input type="submit" id="btnsubmit" name="btnsubmit" value="Guardar">
           <input type="button" id="btnconsultar" name="btnconsulta" value="Consulta" onclick="window.location.href='php/Consulta.php'">
           <input type="reset" id="btnreset" value="Limpiar">
           <input type="button" id="salir" value="Salir" onclick="Salida();">
            </form>
        </center>
    </body>
</html>