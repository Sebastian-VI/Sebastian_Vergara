Create database registro;
Use registro;

Create Table Madres
(
	Cedula_Ma char(15) Primary Key,
	Nombre_Ma Varchar(50)not null,
	Apellido_Ma Varchar(50)not null,
	Profesion_Ma Varchar(50)not null,
	Telefono_Ma Numeric(11)not null,
	Celular_Ma Numeric (9)not null,
	Direccion_Ma Varchar(60)not null
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
Create Table Padres
(
	Cedula_Pa char(15) Primary Key,
	Nombre_Pa Varchar(50)not null,
	Apellido_Pa Varchar (50)not null,
	Profesion_Pa Varchar(50)not null,
	Telefono_Pa Numeric(11)not null,
	Celular_Pa Numeric(9)not null,
	Direccion_Pa Varchar(60)not null	
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

Create Table Alumnos 
(
	Cedula_Al char(15) Primary Key,
	Nombre_Al Varchar(50) not null,
	Apellidos_Al Varchar(50) not null,
	FechaNacimiento_Al Varchar(50) not null,
	Edad_Al Numeric(2) not null,
	Sexo_Al Varchar(9)not null,
	Direccion_Al Varchar(60)not null,
	Telefono_Al Numeric(11)not null,
	Pais_Al Varchar(30) not null,
	Provincia_Al Varchar(30)not null,
	Ciudad_Al Varchar(50)not null,
	Cedula_Pa char(15),
	Cedula_Ma char(15),
	importeTotal float,
	Utilidad float,
	FOREIGN KEY (Cedula_Pa) REFERENCES Padres (Cedula_Pa),
	FOREIGN KEY (Cedula_Ma) REFERENCES Madres (Cedula_Ma)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;



Create Table Docentes
(
	Cedula_Do char(15) Primary Key,
	Nombre_Do Varchar(50)not null,
	Apellidos_Do Varchar(50)not null,
	FechaNacimiento_Do Date not null,
	Pais_Do Varchar(30)not null,
	Ciudad_Do Varchar(30)not null,
	Provincia_Do Varchar(30)not null,
	Telefono_Do Numeric(11)not null,
	Direccion_Do Varchar(60)not null,
	Sexo_Do Varchar(9)not null,
	Profesion_Do Varchar(20)not null,
	Posgrado_Do Varchar (20)not null

)ENGINE=InnoDB DEFAULT CHARSET=latin1;
Create Table Modulos
(
	Codigo_Mo char(4) Primary Key,
	Seccion_Mo Varchar(12)not null,
	Nombre_Mo Varchar(20)not null,
	Carrera_Mo Varchar(30)not null,
	Semestre_Mo Numeric(2)not null,
	Sede_Mo Varchar(20)not null,
	Inicio_Mo date not null,
	Termino_Mo date not null,
	Sala_Mo Numeric(3)not null,
	Bloque_Mo Varchar(4)not null
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
Create Table Notas
(
	Codigo_No INT(8) AUTO_INCREMENT PRIMARY KEY,
	Evaluacion_1 Numeric(2)not null,
	Evaluacion_2 Numeric(2)not null,
	Evaluacion_3 Numeric(2)not null,
	Nota_Examen Numeric(2)not null,
	Examen_1 Numeric(2)not null,
	Examen_2 Numeric(2)not null,
	Nota_Final Numeric(2)not null,
	Estado Varchar(25)not null,
	Cedula_Al char(15),
	Codigo_Mo char(4),
	Cedula_Do char(15),
	FOREIGN KEY (Cedula_Al) REFERENCES Alumnos (Cedula_Al),
	FOREIGN KEY (Codigo_Mo) REFERENCES Modulos (Codigo_Mo),
	FOREIGN KEY (Cedula_Do) REFERENCES Docentes (Cedula_Do)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

Create Table Administradores
(
	Cedula_Ad char(15) Primary Key,
	Nombre_Ad Varchar(50)not null,
	Apellido_Ad Varchar(50)not null,
	Usuario_Ad Varchar(30) not null unique,
	Contrasena_Ad Varchar(10) not null unique,
	Cedula_Do char(15),
	FOREIGN KEY (Cedula_Do) REFERENCES Docentes (Cedula_Do)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO Docentes(Cedula_Do, Nombre_Do, Apellidos_Do) VALUES ('19.459.378-9','Pedro','Valdez');
INSERT INTO Administradores VALUES ('19.459.378-9','Pedro','Valdez','PValdez','xxx123','19.459.378-9');





